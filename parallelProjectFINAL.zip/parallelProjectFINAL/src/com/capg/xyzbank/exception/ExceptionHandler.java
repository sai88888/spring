package com.capg.xyzbank.exception;

public class ExceptionHandler {

}
