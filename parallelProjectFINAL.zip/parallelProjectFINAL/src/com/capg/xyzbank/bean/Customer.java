package com.capg.xyzbank.bean;

public class Customer {
	static int custId = 1;
	private String cID;
	private String custName;
	private Account account;

	public Customer() {

	}

	public Customer(String cID, String custName, Account account) {
		super();
		this.cID = autoGenerateCID();
		this.custName = custName;
		this.account = account;
	}

	public String autoGenerateCID() {
		String str = "C" + custId;
		custId++;
		return str;
	}

	public String getcID() {
		return cID;
	}

	public void setcID(String cID) {
		this.cID = cID;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	@Override
	public String toString() {
		return "Customer [cID=" + cID + ", custName=" + custName + ", account=" + account + "]";
	}

}
