package com.capg.xyzbank.bean;

public enum accountType {

	SAVINGS, CURRENT;

}
