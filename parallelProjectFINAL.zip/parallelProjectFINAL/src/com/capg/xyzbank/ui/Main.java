package com.capg.xyzbank.ui;

import java.util.Scanner;

import com.capg.xyzbank.service.BankServices;

public class Main {
	public static void main(String args[]) {
		int choice = 0;
		String option;
		BankServices almObj = new BankServices();
		Scanner sc = new Scanner(System.in);
		do {
			System.out.println("------------------\nWelcome to XYZ\n------------------\n"
					+ "1. to Create a new Account\n" + "2. to Show Balance\n" + "3. to Deposit Balnce\n"
					+ "4. to withdraw amount\n" + "5. to trnsfer funds \n" + "6. to print Transactions\n" + "7. exit");

			System.out.println("****Enter Your Choice****");
			try {
				choice = sc.nextInt();
			} catch (Exception e) {
				// e.printStackTrace();
				System.out.println(e);
				// System.out.println(e.getMessage());
			}

			switch (choice) {
			case 1:// Creating and Storing new account details
			{
				almObj.newAcc();
				break;
			}
			case 2:// Showing account details
			{
				almObj.showAccDetails();
				break;
			}
			case 3: {
				almObj.deposit();
				break;
			}
			case 4: {
				almObj.withdraw();
				break;
			}
			case 5: {
				almObj.fundTransfer();
				break;
			}
			case 6: {
				almObj.printTransactions();
				break;
			}
			case 7: {
				System.out.println("-----------------------\nTHANK YOU--VISIT AGAIN\n-----------------------");
				System.exit(0);
			}
			default: {
				System.out.println("!!!!!!***YOU HAVE ENTERED WRONG OPTION " + " " + choice + " " + "***!!!!!!");

			}
			}
			System.out.println("\n DO YOU WISH TO CONTINUE:enter :: Yes(y)/No(n)");

			option = sc.next();
			if (option.toUpperCase().equals("YES") || option.toUpperCase().equals("Y")) {
				continue;
			} else {
				System.out.println("------------------\nTHANK YOU--visit again\n-----------------------");
				System.exit(0);
			}

		} while (choice != 1 || choice != 2 || choice != 3 || choice != 4 || choice != 5 || choice != 6 || choice != 7);
		sc.close();
	}
}
