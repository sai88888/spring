package com.capg.xyzbank.dao;

import java.util.HashMap;
import java.util.Scanner;

import com.capg.xyzbank.bean.Customer;
import com.capg.xyzbank.bean.Transactions;

public class StorageDAO {
	Scanner sc = new Scanner(System.in);
	Customer obj;
	Transactions objt;
	HashMap<String, Customer> hm = new HashMap<String, Customer>();
	HashMap<String, Transactions> tranhm = new HashMap<String, Transactions>();

	public void storingMethod(Customer obj) {
		hm.put(obj.getAccount().getAccountNum(), obj);
		
	}

	public void TransactionstoringMethod(Transactions objt) {
		tranhm.put(objt.getTranNumber(), objt);
	}

	public Customer retrieveData(String accountNumber) {
		java.util.Iterator<String> customerKeySet = hm.keySet().iterator();

		while (customerKeySet.hasNext()) {
			if (accountNumber.equals(customerKeySet.next())) {
				return hm.get(accountNumber);

			}
		}
		return null;
	}

	public boolean retrieveDataForExisting(String customerId) {
		java.util.Iterator<String> customerKeySet = hm.keySet().iterator();

		while (customerKeySet.hasNext()) {
			if (customerId.equals(hm.get(customerKeySet.next()).getcID())) {
				
				return true;

			}
		}
		return false;
	}
	
	public HashMap<String, Transactions> retrieveTransactions(String accountNumber) {
		java.util.Iterator<String> customerKeySet = tranhm.keySet().iterator();

		while (customerKeySet.hasNext()) {
			if (accountNumber.equals(customerKeySet.next())) {
				return tranhm;

			}
		}
		return tranhm;
	}


}