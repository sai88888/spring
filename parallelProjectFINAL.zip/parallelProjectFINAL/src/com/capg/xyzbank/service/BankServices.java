package com.capg.xyzbank.service;

import java.util.Map;
import java.util.Scanner;

import com.capg.xyzbank.bean.Account;
import com.capg.xyzbank.bean.Customer;
import com.capg.xyzbank.bean.Transactions;

public class BankServices {
	// Creating and Storing new account details
	AccService serObj = new AccService();
	Scanner sc = new Scanner(System.in);

	public void newAcc() {

		String cId = null;
		String acc = null;
		String tran = null;
		System.out.println("are you a old customer to bank \n ENTER :YES/NO");
		String s = sc.next();
		if (s.toUpperCase().equals("YES") || s.toUpperCase().equals("Y")) {
			System.out.println("Enter your customer id");
			String cd = sc.next();
			if (serObj.retrieveDataForExisting(cd)) {
				System.out.println("your account is existed and activated so you can use our services\n");
				
			}
			else{
				System.out.println("Your CID is not matched with any Existing Customers \n you need to create an account to use bank services");
			}
		} else {
			System.out.println("********you need to create an account to use bank services**********");
			System.out.println("Enter your name");
			String sName = sc.next();
			System.out.println("Enter Account Type You Want/n 1.SAVINGS/n 2.CURRENT");
			String accType = sc.next().toUpperCase();
			System.out.println("Enter minimum balance");
			try {
				double balance = sc.nextDouble();
				Account account = new Account(acc, accType, balance);
				Customer customer = new Customer(cId, sName, account);

				System.out.println(customer.getcID() + "--Account created successfully--");
				serObj.storeData(customer);
				Transactions transaction = new Transactions(tran, customer.getAccount().getAccountNum(), balance);
				serObj.storeTransactions(transaction);
			} catch (Exception e) {
			}
		}
	}

	// Showing account details
	public void showAccDetails() {

		System.out.println("Enter your AccountNumber ");
		String accountNumber = sc.next();
		Customer hmObj = serObj.retrieveData(accountNumber);
		if (hmObj != null) {
			System.out.println(hmObj);
		} else {
			System.out.println("no such account");
		}
	}

	public void deposit() {
		String tran = null;
		System.out.println("Enter account number to dposit");
		String accountNumber = sc.next();
		Customer hmObj = serObj.retrieveData(accountNumber);
		if (hmObj != null) {
			System.out.println("Enter amount to dposit");
			double amount = sc.nextDouble();
			double actual = hmObj.getAccount().getBalance();
			hmObj.getAccount().setBalance(amount + actual);
			System.out.println("--Amount added successfully--");
			Transactions transaction = new Transactions(tran, hmObj.getAccount().getAccountNum(), amount);
			serObj.storeTransactions(transaction);
		} else {
			System.out.println("no such account");
		}
	}

	public void withdraw() {
		String tran = null;
		System.out.println("Enter account number to withdraw");
		String accountNumber = sc.next();
		Customer hmObj = serObj.retrieveData(accountNumber);
		if (hmObj != null) {
			System.out.println("Enter amount to withdraw");
			double amount = sc.nextDouble();
			double balCheck = hmObj.getAccount().getBalance();
			if (balCheck >= amount) {
				hmObj.getAccount().setBalance(balCheck - amount);
				System.out.println("--Amount withdrawal successful--");
				Transactions transaction = new Transactions(tran, hmObj.getAccount().getAccountNum(), null, amount, 0);
				serObj.storeTransactions(transaction);
			} else {
				System.out.println("no sufficient balance");
			}
		} else {
			System.out.println("no such account");
		}
	}

	public void fundTransfer() {
		String tran = null;
		System.out.println("Enter your account number");
		String debitNumber = sc.next();
		Customer debitObj = serObj.retrieveData(debitNumber);
		if (debitObj != null) {
			System.out.println("Enter beneficiary account number");
			String creditNumber = sc.next();
			Customer creditObj = serObj.retrieveData(creditNumber);
			if (debitObj != null) {
				System.out.println("Enter amount to transfer");
				double amount = sc.nextDouble();
				double balCheck = debitObj.getAccount().getBalance();
				double bal = creditObj.getAccount().getBalance();
				if (balCheck >= amount) {
					double remainingBal = balCheck - amount;
					debitObj.getAccount().setBalance(remainingBal);
					creditObj.getAccount().setBalance(bal + amount);
					System.out.println("--Transaction successful--");
					Transactions transactionc = new Transactions(tran, null, creditObj.getAccount().getAccountNum(),
							0.0, amount);
					Transactions transactiond = new Transactions(tran, debitObj.getAccount().getAccountNum(), null,
							amount, 0.0);
					serObj.storeTransactions(transactionc);
					serObj.storeTransactions(transactiond);
				} else {
					System.out.println("no sufficient balance");
				}
			}
		} else {
			System.out.println("no such Account");
		}
	}

	public void printTransactions() {
		int count = 0;
		System.out.println("Enter your AccountNumber ");
		String accountNumber = sc.next();
		Map<String, Transactions> TranObj = serObj.retrieveTransaction(accountNumber);
		if (TranObj != null) {

			for (String key : TranObj.keySet()) {
				if (accountNumber.equals(TranObj.get(key).getDebitAccountNumber())
						|| accountNumber.equals(TranObj.get(key).getCreditAccountNumber())) {

					System.out.println(count + ":" + TranObj.get(key));
					count++;
				}

			}

		} else {
			System.out.println("no such account");
		}
	}
}
