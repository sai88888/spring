package com.capg.xyzbank.service;

import java.util.HashMap;

import com.capg.xyzbank.bean.Customer;
import com.capg.xyzbank.bean.Transactions;
import com.capg.xyzbank.dao.StorageDAO;

public class AccService {

	StorageDAO daObj = new StorageDAO();
	Customer accShowBalObj = new Customer();

	public void storeData(Customer obj) {
		daObj.storingMethod(obj);
	}

	public void storeTransactions(Transactions obj) {
		daObj.TransactionstoringMethod(obj);
	}

	public Customer retrieveData(String accountNumber) {
		Customer deeObj = daObj.retrieveData(accountNumber);
		return deeObj;

	}
	
	public boolean retrieveDataForExisting(String customerId) {
		Boolean bool =  daObj.retrieveDataForExisting(customerId);
		
		return bool;
	
	}

	
	
	public HashMap<String, Transactions> retrieveTransaction(String accountNumber) {
		HashMap<String, Transactions> tranObj = daObj.retrieveTransactions(accountNumber);
		return tranObj;

	}
}
