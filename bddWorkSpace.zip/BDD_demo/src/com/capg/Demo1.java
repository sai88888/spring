package com.capg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Demo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String str ="C:\\Users\\saikota\\Drivers\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", str);
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("http:\\www.google.com");
		
		WebElement wb =driver.findElement(By.name("q"));
		
		wb.sendKeys("Chennai Climate");
		
	//WebElement wb2=	driver.findElement(By.className("sbl1"));
	
	wb.sendKeys("\n");
	}

}
