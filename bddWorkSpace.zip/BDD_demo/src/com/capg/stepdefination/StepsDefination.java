package com.capg.stepdefination;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepsDefination {
	WebDriver driver;
	@Given("^Open Any Browser and Enter Icompass URL$")
	public void open_Any_Browser_and_Enter_Icompass_URL() throws Throwable {

		String str = "C:\\Users\\saikota\\Drivers\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", str);

		driver = new ChromeDriver();
		String str2 = "https://icompassweb.fs.capgemini.com";
		driver.get(str2);

	}

	@When("^User Enters valid username \"([^\"]*)\" valid password \"([^\"]*)\"$")
	public void user_Enters_valid_username_valid_password(String userName, String password) throws Throwable {
        
		WebElement element = driver.findElement(By.id("userName"));
		WebElement element2 =driver.findElement(By.id("password"));
		element.sendKeys(userName);
		element2.sendKeys(password);
	}

	@Then("^Login in to Icompass successfully$")
	public void login_in_to_Icompass_successfully() throws Throwable {
		
		WebElement login =driver.findElement(By.id("loginButton"));
		login.click();
	}

}
