package com.capg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.bean.Product;
import com.capg.dao.ProductDao;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductDao repository;
	
	public void addProduct(Product product) {
		repository.save(product);
	}

	@Override
	public List<Product> getAll() {
		return repository.findAll();
	}
	
}
