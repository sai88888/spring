package com.capg.controller;

public class EmployeeExp extends Exception{

}
